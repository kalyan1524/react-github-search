# 🔍 GitHub User Search App

This is a simple React app that allows users to search for GitHub usernames and displays basic profile information using the GitHub API.

## Features
- Username input field
- Displays avatar, name, bio, repo count, and followers
- Handles loading and error states
- Clean, responsive design with basic CSS

## Demo
Run locally:
```
npm install
npm start
```

## Built With
- React
- GitHub REST API
- CSS